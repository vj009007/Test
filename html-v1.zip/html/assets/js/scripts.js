
$(document).ready(function(){
  $('.slider').slick({
  dots: false,
  infinite: true,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 1,
  prevArrow:"<button type='button' class='slick-prev pull-left'><i class='slider-arrow' aria-hidden='true'></i></button>",
	nextArrow:"<button type='button' class='slick-next pull-right'><i class='slider-arrow' aria-hidden='true'></i></button>",
  responsive: [
    {
      breakpoint: 1150,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 900,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
		centerMode: true,
		centerPadding: '50px'
      }
    }

  ]
});
});



$(document).ready(function(){
	$('nav ul').slicknav();
});
